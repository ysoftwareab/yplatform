# frozen_string_literal: false
require 'drb/drb'

